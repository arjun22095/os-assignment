gcc main.c texts.c history.c custerrors.c filelocks.c
gcc  -o ss simplesched.c -lm subsched.c filelocks.c filelocks.h texts.c
./a.out